<?
$MESS ['MENU_VERTICAL_MULTI_NAME'] = "Вертикальное многоуровневое выпадающее меню";
$MESS ['MENU_VERTICAL_MULTI_DESC'] = "Вертикальное многоуровневое выпадающее меню";
?>