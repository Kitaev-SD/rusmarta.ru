<?
$MESS["MENU_VERTICAL_MULTI_NAME"] = "Вертикальне багаторівневе меню, що випадає";
$MESS["MENU_VERTICAL_MULTI_DESC"] = "Вертикальне багаторівневе меню, що випадає";
?>