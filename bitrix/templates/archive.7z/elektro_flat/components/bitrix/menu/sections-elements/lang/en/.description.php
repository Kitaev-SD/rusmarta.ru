<?
$MESS ['MENU_VERTICAL_MULTI_NAME'] = "Vertical multi level dropdown menu";
$MESS ['MENU_VERTICAL_MULTI_DESC'] = "Vertical multi level dropdown menu";
?>