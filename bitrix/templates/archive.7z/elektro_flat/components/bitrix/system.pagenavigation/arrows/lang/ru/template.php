<?
$MESS ['PREVIOUS_PAGE'] = "&larr;&nbsp;Ctrl";
$MESS ['NEXT_PAGE'] = "Ctrl&nbsp;&rarr;";
?>