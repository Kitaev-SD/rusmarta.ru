<?
$MESS ['nav_prev'] = "&larr;&nbsp;Ctrl";
$MESS ['nav_next'] = "Ctrl&nbsp;&rarr;";
?>