<?
$MESS["ENABLE_JAVASCRIPT"] = "JavaScript is disabled in your browser";
$MESS["JS_PLAYLISTERROR"] = "Error occurred during playlist load";
$MESS["JS_CLICKTOPLAY"] = "Click to play";
$MESS["JS_LINK"] = "Download...";
$MESS["PLAYER_LOADING"] = "Loading Player";
?>