<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

ShowNote(Loc::getMessage("EMPTY_BASKET_TITLE"), "infotext");?>